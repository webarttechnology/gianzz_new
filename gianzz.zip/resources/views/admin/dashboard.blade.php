<x-adminheader />
<x-adminnav />
<div class="app-content">
					<section class="section">

					    <!--page-header open-->
						<div class="page-header">
							<h4 class="page-title">Admin Dashboard</h4>
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="#" class="text-light-color">Home</a></li>
								<li class="breadcrumb-item active" aria-current="page">Dashboard </li>
							</ol>
						</div>
						<!--page-header closed-->
<div class="row">

</div>
</section>
</div>

<x-adminfooter />