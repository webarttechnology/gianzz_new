<x-header-component/>

<div class="userDashboard">
	<div class="container">
		<div class="row">
			<div class="col-md-3">
            <x-sidebar activeid="3" />
			</div>
			<div class="col-md-9">
				<div class="dashboardBg">
					<h2>Changes password</h2>
					<div class="row">
						<div class="col-md-6">
							<div class="mb-3">
							  <label for="exampleFormControlInput1" class="form-label">password</label>
							  <input type="email" class="form-control" placeholder="First Name">
							</div>
						</div>
						<div class="col-md-6">
							<div class="mb-3">
							  <label for="exampleFormControlInput1" class="form-label">Confrim password</label>
							  <input type="email" class="form-control" placeholder="Last Name">
							</div>
						</div>
						
					</div>
					<div class="row">
						<div class="col-md-12"><button type="button" class="btn btn-primary w-25">Update</button></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<x-footer-component/>