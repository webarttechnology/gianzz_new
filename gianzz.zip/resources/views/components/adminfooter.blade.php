				<!--Footer-->
				<footer class="main-footer">
					<div class="text-center">
						Copyright ©Splite 2019. Design By<a href=""></a>
					</div>
				</footer>
				<!--/Footer-->

				<!-- Popupchat open-->
				
				<!-- Popupchat closed -->

			</div>
		</div>
		<!--app closed-->

		<!-- Back to top -->
		<a href="#top" id="back-to-top" style="display: inline;"><i class="fa fa-angle-up"></i></a>

		<!-- Popup-chat -->
		
        <!--Jquery.min js-->
		<script src="{{asset('/assets/js/jquery.min.js')}}"></script>
	

		<!--popper js-->
		<script src="{{asset('/assets/js/popper.js')}}"></script>

		<!--Bootstrap.min js-->
		<script src="{{asset('/assets/plugins/bootstrap/js/bootstrap.min.js')}}"></script>
		
		<!--Tooltip js-->
		<script src="{{asset('/assets/js/tooltip.js')}}"></script>

		<!-- Jquery star rating-->
		<script src="{{asset('/assets/plugins/rating/jquery.rating-stars.js')}}"></script>
	<!--Horizontalmenu js-->
	<script src="{{asset('/assets/plugins/horizontal-menu/webslidemenu.js')}}"></script>

		<!--Jquery.nicescroll.min js-->
		<script src="{{asset('/assets/plugins/nicescroll/jquery.nicescroll.min.js')}}"></script>

		<!--Scroll-up-bar.min js-->
		<script src="{{asset('/assets/plugins/scroll-up-bar/dist/scroll-up-bar.min.js')}}"></script>

		<!--mCustomScrollbar js-->
		<script src="{{asset('/assets/plugins/scroll-bar/jquery.mCustomScrollbar.concat.min.js')}}"></script>

		<!--Sidemenu js-->
		<script src="{{asset('/assets/plugins/toggle-menu/sidemenu.js')}}"></script>

	

		<!--Showmore js-->
		<script src="{{asset('/assets/js/jquery.showmore.js')}}"></script>

		<!--Scripts js-->
		<script src="{{asset('/assets/js/scripts.js')}}"></script>
		<script src="{{asset('/assets/js/dashboard2.js')}}"></script>
		<script src="{{asset('/assets/js/othercharts.js')}}"></script>
		<script src="{{asset('/assets/js/sparkline.js')}}"></script>
		<!--Chart js-->
		<script src="{{asset('/assets/plugins/Chart.js/dist/Chart.min.js')}}"></script>
		<script src="{{asset('/assets/plugins/Chart.js/dist/Chart.extension.js')}}"></script>

		<!--other char js -->
		<script src="{{asset('/assets/plugins/othercharts/jquery.knob.js')}}"></script>
		<script src="{{asset('/assets/plugins/othercharts/jquery.sparkline.min.js')}}"></script>

		<!--Morris js-->
		<script src="{{asset('/assets/plugins/morris/morris.min.js')}}"></script>
		<script src="{{asset('/assets/plugins/morris/raphael.min.js')}}"></script>
		

	
</div></body>

	</html>